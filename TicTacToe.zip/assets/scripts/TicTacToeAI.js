/*
Vivek Sharma
02/11/2019
*/

var Board = require("./Board");
const { SYMBOLS, RESULT } = require("./TIC_TAC_TOE_Constants");

exports.aiInstance = function() {
  var ai = {};

  ai.bestMove = function(boardInstance, symbol, isAI = true) {
    let tempBoard = boardInstance.matrix;
    let availableMoves = boardInstance.getEmptyCells();
    let movesWithScore = [];

    for (let i = 0; i < availableMoves.length; i++) {
      let move = availableMoves[i];
      let newBoard = Board.init({ matrix: tempBoard });
      let result = newBoard.applyMove(move.i, move.j, symbol).result;
      let otherSymbol = SYMBOLS.x === symbol ? SYMBOLS.o : SYMBOLS.x;
      let score = 0;
      if (result === RESULT.NONE) {
        let nextMove = this.bestMove(newBoard, otherSymbol, !isAI);
        score = nextMove.score;
      } else {
        let aiMoves = newBoard.getElementCount(isAI ? symbol : otherSymbol);
        score = scoreCalculator(result, isAI ? symbol : otherSymbol, aiMoves);
      }
      movesWithScore.push({ move, score });
    }

    actionsSorting(movesWithScore, !isAI);

    return movesWithScore.length ? movesWithScore[0] : {};
  };

  function actionsSorting(actions, isAscending = true) {
    actions.sort((a, b) => {
      return isAscending ? b.score - a.score : a.score - b.score;
    });
  }

  function scoreCalculator(result, aiSymbol, aiMovesCount) {
    if (result === RESULT.TIE) {
      return 0;
    }

    if (result === aiSymbol) {
      //AI WINS
      return -10 + aiMovesCount;
    }

    return 10 - aiMovesCount; //PLAYER WINS
  }
  return ai;
};
