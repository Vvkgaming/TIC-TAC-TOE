/*
Vivek Sharma
02/11/2019
*/

const {
  EMPTY_BOARD,
  getCopyArray,
  SYMBOLS,
  RESULT,
  WINNING_COMBINATIONS
} = require("./TIC_TAC_TOE_Constants");

exports.init = function(options) {
  var board = {
    matrix: getCopyArray(
      options && options.matrix ? options.matrix : EMPTY_BOARD
    ), //matrix is actual board
    turn: SYMBOLS.x //Set initial turn can be random
  };
  // This function calculates count of element on board based on matching bool
  board.getElementCount = function(element, matching = true) {
    let moves = 0;
    for (let i = 0; i < board.matrix.length; i++) {
      moves += board.matrix[i].filter(value => {
        return matching ? value === element : value !== element;
      }).length;
    }
    return moves;
  };

  //This function return result with winning line if any there
  function getResult(symbol) {
    let result = RESULT.NONE;
    let movesCount = board.getElementCount("", false);
    //If moves count less then 5 then there is no need to calculate result
    if (movesCount < 5) return { result };

    for (let i = 0; i < WINNING_COMBINATIONS.length; i++) {
      let comb = WINNING_COMBINATIONS[i];
      let match = 0;
      for (let j = 1; j < comb.length; j++) {
        //Row and columns calculation of element
        let c1 = comb[j - 1] % comb.length;
        let r1 = Math.floor(comb[j - 1] / comb.length);
        let c2 = comb[j] % comb.length;
        let r2 = Math.floor(comb[j] / comb.length);

        //check if there is a match else move to next combintation
        if (
          board.matrix[r1][c1] !== "" &&
          board.matrix[r1][c1] === board.matrix[r2][c2]
        ) {
          match++; //match found
        } else {
          break; //match not found move to next combinations
        }

        //check if one of the combination fully matched
        if (match === comb.length - 1) {
          result = symbol === SYMBOLS.o ? RESULT.O_WON : RESULT.X_WON;
          return { result, comb };
        }
      }
    }

    //Check for tie condition
    if (movesCount === 9) {
      result = RESULT.TIE;
      return { result };
    }

    //No termianl condition found
    return { result };
  }

  //apply a move on board and return result (state) of board like WIN ,TIE with combination
  board.applyMove = function(row, column, symbol) {
    board.matrix[row][column] = symbol;
    // return board.matrix;
    return getResult(symbol);
  };

  board.getEmptyCells = function() {
    let availableMoves = [];
    for (let i = 0; i < board.matrix.length; i++) {
      for (let j = 0; j < board.matrix[i].length; j++) {
        if (board.matrix[i][j] === "") availableMoves.push({ i, j });
      }
    }
    return availableMoves;
  };

  return board;
};
