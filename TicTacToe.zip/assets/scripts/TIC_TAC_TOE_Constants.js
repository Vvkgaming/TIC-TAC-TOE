/*
Vivek Sharma
02/11/2019
*/

exports.SYMBOLS = {
  x: "X",
  o: "O"
};

exports.getCopyArray = function(array) {
  let temp = [];
  for (let i = 0; i < array.length; i++) {
    temp.push([]);
    for (let j = 0; j < array[i].length; j++) temp[i].push(array[i][j]);
  }
  return temp;
};

exports.WINNING_COMBINATIONS = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

exports.RESULT = {
  NONE: 0,
  X_WON: exports.SYMBOLS.x,
  O_WON: exports.SYMBOLS.o,
  TIE: 100
};

exports.EMPTY_BOARD = [["", "", ""], ["", "", ""], ["", "", ""]];
