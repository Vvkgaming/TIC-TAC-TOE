/*
Vivek Sharma
02/11/2019
*/

var Board = require("./Board");
const { SYMBOLS, RESULT } = require("./TIC_TAC_TOE_Constants");

var TicTacToeAI = require("./TicTacToeAI");
cc.Class({
  extends: cc.Component,

  properties: {
    X_Icon: {
      default: null,
      type: cc.SpriteFrame
    },
    O_ICON: {
      default: null,
      type: cc.SpriteFrame
    },
    cells: {
      default: [],
      type: cc.Sprite
    },
    resultLabel: {
      type: cc.Label,
      default: null
    }
  },

  start() {
    this.resultLabel.string = "";
    this.gameBoard = Board.init();
    this.AI = TicTacToeAI.aiInstance();
  },

  onButtonClick(e, index) {
    if (this.gameBoard.turn === SYMBOLS.o || this.cells[index].spriteFrame)
      return;
    this.gameBoard.turn = SYMBOLS.o;
    let row = Math.floor(index / 3);
    let column = index % 3;
    this.cells[index].spriteFrame = this.X_Icon;
    this.cells[index].node.active = true;
    let isGameOver = this.setMove(row, column, SYMBOLS.x, this.X_Icon);
    if (!isGameOver) this.aiAction();
  },

  aiAction() {
    let action = this.AI.bestMove(this.gameBoard, SYMBOLS.o);
    if (Object.keys(action).length) {
      this.setMove(action.move.i, action.move.j, SYMBOLS.o, this.O_ICON);
      this.gameBoard.turn = SYMBOLS.x;
    }
  },

  setMove(row, column, symbol, icon) {
    let boardState = this.gameBoard.applyMove(row, column, symbol);
    this.cells[row * 3 + column].spriteFrame = icon;
    this.cells[row * 3 + column].node.active = true;

    if (boardState.result !== RESULT.NONE) {
      this.gameOver(boardState);
      return true;
    }

    return false;
  },

  gameOver(boardState) {
    console.log("result  is ", JSON.stringify(boardState));
    this.resultLabel.string =
      boardState.result === 100 ? "TIED" : boardState.result + "  WON";

    setTimeout(() => {
      cc.director.loadScene("Game");
    }, 5000);
  }
});
